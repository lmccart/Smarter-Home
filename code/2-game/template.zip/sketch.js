function setup() {
  startTracking();
  createCanvas(100, 100);
  background(200);
}


function draw() {

}

function circleHit() {
  background(random(255), random(255), random(255));
}